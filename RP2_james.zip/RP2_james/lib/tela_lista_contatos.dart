import 'package:flutter/material.dart';
import 'contato.dart';
import 'tela_adicionar_contato.dart';
import 'tela_detalhes_contato.dart'; // Certifique-se de importar a tela de detalhes

class TelaListaContatos extends StatefulWidget {
  final List<Contato> contatos;

  TelaListaContatos({required this.contatos});

  @override
  _TelaListaContatosState createState() => _TelaListaContatosState();
}

class _TelaListaContatosState extends State<TelaListaContatos> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agenda de Contatos'),
      ),
      body: ListView.builder(
        itemCount: widget.contatos.length,
        itemBuilder: (ctx, index) {
          return Column(
            children: [
              ListTile(
                leading: Icon(Icons.person),
                title: Text(widget.contatos[index].nome),
                subtitle: Text(widget.contatos[index].telefone),
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => TelaDetalhesContato(contato: widget.contatos[index]), // Passando o contato como argumento
                    ),
                  );
                },
              ),
              SizedBox(height: 8),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => TelaAdicionarContato(),
            ),
          ).then((novoContato) {
            if (novoContato != null) {
              print('Novo contato adicionado: $novoContato');
              setState(() {
                widget.contatos.add(novoContato);
              });
              print('Lista de contatos atualizada: ${widget.contatos}');
            }
          });
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
