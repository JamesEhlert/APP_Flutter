import 'package:flutter/material.dart';
import 'contato.dart';

class TelaAdicionarContato extends StatefulWidget {
  @override
  _TelaAdicionarContatoState createState() => _TelaAdicionarContatoState();
}

class _TelaAdicionarContatoState extends State<TelaAdicionarContato> {
  final _formKey = GlobalKey<FormState>();
  final nomeController = TextEditingController();
  final telefoneController = TextEditingController();
  TipoContato _selectedTipo = TipoContato.pessoal;

  @override
  void dispose() {
    nomeController.dispose();
    telefoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Contato'),
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                TextFormField(
                  controller: nomeController,
                  decoration: InputDecoration(labelText: 'Nome'),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Digite o nome do contato';
                    }
                    return null;
                  },
                ),
                TextFormField(
                  controller: telefoneController,
                  decoration: InputDecoration(labelText: 'Telefone'),
                  validator: (value) {
                    if (value?.isEmpty ?? true) {
                      return 'Digite o telefone do contato';
                    }
                    return null;
                  },
                ),
                RadioListTile<TipoContato>(
                  title: Text('Pessoal'),
                  value: TipoContato.pessoal,
                  groupValue: _selectedTipo,
                  onChanged: (value) {
                    setState(() {
                      _selectedTipo = value!;
                    });
                  },
                ),
                RadioListTile<TipoContato>(
                  title: Text('Trabalho'),
                  value: TipoContato.trabalho,
                  groupValue: _selectedTipo,
                  onChanged: (value) {
                    setState(() {
                      _selectedTipo = value!;
                    });
                  },
                ),
                RadioListTile<TipoContato>(
                  title: Text('Família'),
                  value: TipoContato.familia,
                  groupValue: _selectedTipo,
                  onChanged: (value) {
                    setState(() {
                      _selectedTipo = value!;
                    });
                  },
                ),
                RadioListTile<TipoContato>(
                  title: Text('Amigo'),
                  value: TipoContato.amigo,
                  groupValue: _selectedTipo,
                  onChanged: (value) {
                    setState(() {
                      _selectedTipo = value!;
                    });
                  },
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState?.validate() ?? false) {
                      String nome = nomeController.text ?? '';
                      String telefone = telefoneController.text ?? '';

                      Contato novoContato = Contato(
                        nome: nome,
                        telefone: telefone,
                        tipoContato: _selectedTipo,
                      );

                      Navigator.pop(context, novoContato); // Retorna o novo contato
                    }
                  },
                  child: Text('Adicionar Contato'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
