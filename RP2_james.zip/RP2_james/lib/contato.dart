enum TipoContato {
  pessoal,
  trabalho,
  familia,
  amigo,
}

class Contato {
  final String nome;
  final String telefone;
  final TipoContato tipoContato; // Corrigido para "tipoContato"

  Contato({required this.nome, required this.telefone, required this.tipoContato});
}
