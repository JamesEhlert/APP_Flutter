import 'package:flutter/material.dart';
import 'contato.dart';

class TelaDetalhesContato extends StatelessWidget {
  final Contato contato; // Recebendo o contato como argumento

  TelaDetalhesContato({required this.contato});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes do Contato'),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Nome: ${contato.nome}'),
          Text('Telefone: ${contato.telefone}'),
          Text('Tipo de Contato: ${contato.tipoContato.toString().split('.').last}'),
        ],
      ),
    );
  }
}
