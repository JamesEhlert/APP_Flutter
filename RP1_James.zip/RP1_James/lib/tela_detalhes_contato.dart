import 'package:flutter/material.dart';
import 'contato.dart';

class TelaDetalhesContato extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final Contato? contato = ModalRoute.of(context)?.settings.arguments as Contato?;

    return Scaffold(
      appBar: AppBar(
        title: Text('Detalhes do Contato'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Nome: ${contato?.nome ?? "Nenhum nome"}'),
            Text('Telefone: ${contato?.telefone ?? "Nenhum telefone"}'),
          ],
        ),
      ),
    );
  }
}
