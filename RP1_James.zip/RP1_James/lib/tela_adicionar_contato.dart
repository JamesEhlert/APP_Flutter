import 'package:flutter/material.dart';

class TelaAdicionarContato extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Adicionar Contato'),
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextFormField(
              decoration: InputDecoration(labelText: 'Nome'),
            ),
            SizedBox(height: 16),
            TextFormField(
              decoration: InputDecoration(labelText: 'Telefone'),
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
            
              },
              child: Text('Adicionar Contato'),
            ),
          ],
        ),
      ),
    );
  }
}
