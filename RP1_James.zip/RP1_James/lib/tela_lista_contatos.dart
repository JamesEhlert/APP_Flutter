import 'package:flutter/material.dart';
import 'contato.dart';
import 'tela_adicionar_contato.dart';

class TelaListaContatos extends StatelessWidget {
  final List<Contato> contatos = [
    Contato('Fulano', '123456789'),
    Contato('Ciclano', '987654321'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Agenda de Contatos'),
      ),
      body: ListView.builder(
        itemCount: contatos.length,
        itemBuilder: (ctx, index) {
          return Column(
            children: [
              ListTile(
                leading: Icon(Icons.person), 
                title: Text(contatos[index].nome),
                subtitle: Text(contatos[index].telefone),
                onTap: () {
                  Navigator.pushNamed(context, '/detalhes',
                      arguments: contatos[index]);
                },
              ),

              SizedBox(height: 8), // espaçamento entre os itens da lista
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => TelaAdicionarContato()));
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
