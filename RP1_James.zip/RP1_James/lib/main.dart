import 'package:flutter/material.dart';
import 'tela_lista_contatos.dart';
import 'tela_detalhes_contato.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primaryColor: Colors.green,
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.green),
        fontFamily: 'Roboto',
      ),
      routes: {
        '/': (context) => TelaListaContatos(),
        '/detalhes': (context) => TelaDetalhesContato(),
      },
    );
  }
}
