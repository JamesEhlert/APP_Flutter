class Contato {
  final String nome;
  final String telefone;

  Contato(this.nome, this.telefone);
}
